@javax.xml.bind.annotation.XmlSchema(namespace = "http://schemas.datacontract.org/2004/07/DenariusCoreBanking.Web.ExternalServices", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package servicioclientes.org.datacontract.schemas._2004._07.denariuscorebanking_web;
