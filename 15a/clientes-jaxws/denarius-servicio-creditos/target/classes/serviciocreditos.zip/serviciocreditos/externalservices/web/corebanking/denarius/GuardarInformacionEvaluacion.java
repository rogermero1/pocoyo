
package serviciocreditos.externalservices.web.corebanking.denarius;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import serviciocreditos.org.datacontract.schemas._2004._07.denariuscorebanking_web_externalservices.MEInformacionEvaluacion;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="meInformacionEvaluacion" type="{http://schemas.datacontract.org/2004/07/DenariusCoreBanking.Web.ExternalServices.Creditos}MEInformacionEvaluacion" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "meInformacionEvaluacion"
})
@XmlRootElement(name = "GuardarInformacionEvaluacion")
public class GuardarInformacionEvaluacion {

    @XmlElementRef(name = "meInformacionEvaluacion", namespace = "Denarius.CoreBanking.Web.ExternalServices", type = JAXBElement.class, required = false)
    protected JAXBElement<MEInformacionEvaluacion> meInformacionEvaluacion;

    /**
     * Obtiene el valor de la propiedad meInformacionEvaluacion.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link MEInformacionEvaluacion }{@code >}
     *     
     */
    public JAXBElement<MEInformacionEvaluacion> getMeInformacionEvaluacion() {
        return meInformacionEvaluacion;
    }

    /**
     * Define el valor de la propiedad meInformacionEvaluacion.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link MEInformacionEvaluacion }{@code >}
     *     
     */
    public void setMeInformacionEvaluacion(JAXBElement<MEInformacionEvaluacion> value) {
        this.meInformacionEvaluacion = value;
    }

}
