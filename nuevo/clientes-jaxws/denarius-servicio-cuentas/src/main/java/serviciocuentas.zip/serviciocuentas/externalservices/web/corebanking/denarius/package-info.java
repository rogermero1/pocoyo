@javax.xml.bind.annotation.XmlSchema(namespace = "Denarius.CoreBanking.Web.ExternalServices", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package serviciocuentas.externalservices.web.corebanking.denarius;
