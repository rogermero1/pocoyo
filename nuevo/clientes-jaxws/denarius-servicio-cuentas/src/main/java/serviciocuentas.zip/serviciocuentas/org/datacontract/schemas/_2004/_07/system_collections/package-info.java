@javax.xml.bind.annotation.XmlSchema(namespace = "http://schemas.datacontract.org/2004/07/System.Collections.Generic", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package serviciocuentas.org.datacontract.schemas._2004._07.system_collections;
