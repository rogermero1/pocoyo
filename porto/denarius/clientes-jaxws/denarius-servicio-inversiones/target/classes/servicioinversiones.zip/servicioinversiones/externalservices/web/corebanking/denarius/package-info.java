@javax.xml.bind.annotation.XmlSchema(namespace = "Denarius.CoreBanking.Web.ExternalServices.Inversiones", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package servicioinversiones.externalservices.web.corebanking.denarius;
