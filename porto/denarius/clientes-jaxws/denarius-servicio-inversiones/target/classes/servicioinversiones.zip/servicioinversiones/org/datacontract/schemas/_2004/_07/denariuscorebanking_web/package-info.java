@javax.xml.bind.annotation.XmlSchema(namespace = "http://schemas.datacontract.org/2004/07/DenariusCoreBanking.Web.ExternalServices.Inversiones", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package servicioinversiones.org.datacontract.schemas._2004._07.denariuscorebanking_web;
