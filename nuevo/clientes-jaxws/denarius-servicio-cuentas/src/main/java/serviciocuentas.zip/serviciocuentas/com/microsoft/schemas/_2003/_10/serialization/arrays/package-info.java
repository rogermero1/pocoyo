@javax.xml.bind.annotation.XmlSchema(namespace = "http://schemas.microsoft.com/2003/10/Serialization/Arrays", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package serviciocuentas.com.microsoft.schemas._2003._10.serialization.arrays;
